DROP TABLE IF EXISTS DOCUMENTDATA;

CREATE TABLE DOCUMENTDATA(
docid varchar(10) PRIMARY KEY,
docname varchar(30),
doclocation varchar(100));