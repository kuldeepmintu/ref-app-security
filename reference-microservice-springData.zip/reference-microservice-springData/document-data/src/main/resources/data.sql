

INSERT INTO DOCUMENTDATA
(docid, docname, doclocation)
VALUES('1','Aadhar','my D drive');

INSERT INTO DOCUMENTDATA
(docid, docname, doclocation)
VALUES('2','PAN','HardDisk');
