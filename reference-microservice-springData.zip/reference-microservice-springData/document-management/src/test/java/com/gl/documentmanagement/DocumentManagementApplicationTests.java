package com.gl.documentmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocumentManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
